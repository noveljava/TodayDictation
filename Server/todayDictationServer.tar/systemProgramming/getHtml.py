import urllib2
html = urllib2.urlopen('http://www.voanews.com/learningenglish/home/world', timeout=10).read()
print html

def function():
	print 'called function'
	a = 'test String'
	b = a.find('String')
	print b
	return 

print 'hello world'
function()

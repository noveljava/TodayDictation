import sgmllib

class ExtrTextParser(sgmllib.SGMLParser):
	def __init__(self, verbose=0):
		sgmllib.SGMLParser.__init__(self, verbose)

		self.data = ''

	def handle_data(self, data):
		self.data += data

	def getresult(self):
		return self.data

s = '''<html><head><title>This is title</title></heaD>
<body>
<h2>this is a heading</h2>
<a href="http://www.python.or.kr:8080/python/">Python Information Plaze</a>
<a href="mailto:gslee@mail.kw.ac.kr">Gang Seong Lee</a>
<p> qmffk qmffk</p>
<p> wtf </p>
</body>
</html>'''

parser = ExtrTextParser()
parser.feed(s)
parser.close()
print parser.getresult()


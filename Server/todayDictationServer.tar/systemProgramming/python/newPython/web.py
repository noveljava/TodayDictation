import urllib2, string
import urlparse
import sgmllib
import MySQLdb
import datetime

from BeautifulSoup import BeautifulSoup

#sgmllib.SGMLParser
class ExtrTextParser(sgmllib.SGMLParser):
	def __init__(self, verbose=0):
		sgmllib.SGMLParser.__init__(self, verbose)
		self.data = ''
		
	def handle_data(self, data):
		self.data += data
	
	def getresult(self):
		return self.data

def getHtmlSource() :
	htmlSource = urllib2.urlopen('http://learningenglish.voanews.com/archive/learningenglish-home-world/latest/957/957.html')
	return htmlSource

def checkDb(title) : 
	db = MySQLdb.connect(db='testDB', user='root', passwd='thsdydtjr2', charset='utf8', use_unicode=True)
	
	cursor = db.cursor()
	cursor.execute('select title from testTable where title = "%s"', title)
	data = cursor.fetchone()

	if data == None :
		return True
	else :
		return False

def getTitle() :
	htmlSource = getHtmlSource()
	htmlSource = BeautifulSoup(htmlSource)
	body = str(htmlSource('div', {'class': 'middle_content',}))

	body = BeautifulSoup(body)
	tempLink = body.findAll('a')
	titleList = []

	for temp in tempLink:
		if temp.find('img') == None:
			test = temp['href']
			if test.find('content') > 0:
				titleList.append(temp)
				
	for title in titleList:
		titleS = str(title.contents)
		titleS = titleS[3:len(titleS)-2]

		while titleS.find('\u') != -1:
			titleS = titleS.replace('\u', '')

		checkDb(titleS)
		if titleS != 'More':
			if checkDb(titleS) :
				contents, mp3Url = requestContents(title['href'])
				storeDb(titleS, contents, mp3Url)

def exceptionMp3(url):
	url = 'http://learningenglish.voanews.com' + url
	htmlSource = urllib2.urlopen(url, timeout=10).read()
	soup = BeautifulSoup(htmlSource)

	mp3Url = soup.find('li', {'class': 'downloadlinkstatic'})
	mp3Url = str(mp3Url)
	if mp3Url.find('Mp3') != -1:
		mp3Url = mp3Url[mp3Url.find('http'): mp3Url.find('Mp3')+3]
	elif mp3Url.find('mp3') != -1:
		mp3Url = mp3Url[mp3Url.find('http'): mp3Url.find('mp3')+3]
	return mp3Url

def requestContents(url):
	url = 'http://learningenglish.voanews.com' + url
	htmlSource = urllib2.urlopen(url, timeout=10).read()
	soup = BeautifulSoup(htmlSource)
	contents = soup.findAll('div', {'class': 'articleContent'})
	
	contents = str(contents)
	
	if contents.find('Mp3') != -1:
		mp3Url = contents[contents.find('Mp3')-150: contents.find('Mp3')+3]
		mp3Url = mp3Url[mp3Url.find('www'): ]
		mp3Url = 'http://' + mp3Url
	elif contents.find('mp3') != -1:
		mp3Url = contents[contents.find('mp3')-150: contents.find('mp3')+3]
		mp3Url = mp3Url[mp3Url.find('www'): ]
		mp3Url = 'http://' + mp3Url
	else:
		mp3 = soup.findAll('li', {'class': 'listenlink'})
		mp3 = str(mp3)
		mp3 = mp3[ mp3.find('href')+6: mp3.find('html')+4]
		mp3Url = exceptionMp3(mp3)

	parser = ExtrTextParser()
	parser.feed(contents)
	parser.close()

	contents = parser.getresult()
	
	if contents.find('PDF') == -1 :
		contents = contents[contents.find('This'): ]
	else:
		contents = contents[contents.find('PDF')+4: ]
	
	while contents.find('\t') != -1:
		contents = contents.replace('\t', '')
	
	while contents.find('\n\n') != -1:
		contents = contents.replace('\n\n', '\n')

	return contents, mp3Url

def storeDb(title, content, url):
#	now = datetime.datetime.now()
#	now = str(now)

#	now = now[0:19]

	db = MySQLdb.connect(db='testDB', user='root', passwd='thsdydtjr2', charset='utf8', use_unicode=True)

	cursor=db.cursor()

	now = '2010-09-10 10:10:10'
	cursor.execute('insert into testTable(title, content, mp3url, InputDate) values("%s", "%s", "%s",now() )', (title,content,url))

	cursor.close()
	db.close()

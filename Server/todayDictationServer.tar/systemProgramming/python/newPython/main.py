import web

print web.getTitle()

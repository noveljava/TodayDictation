class Singer:
	def __init__(self, test=0):
		print 'init'
		self.data = ''

	def test(self):
		self.data += 'hello'

	def getResult(self):
		return self.data

test = Singer()
test.test()
test.test()
print test.getResult()

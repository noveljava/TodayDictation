import urllib2, string
import urlparse
import sgmllib
import MySQLdb
import datetime

from BeautifulSoup import BeautifulSoup

class ExtrTextParser(sgmllib.SGMLParser):
        def __init__(self, verbose=0):
                sgmllib.SGMLParser.__init__(self, verbose)

                self.data = ''

        def handle_data(self, data):
                self.data += data
	
        def getresult(self):
                return self.data

def requestWebHtml():
	html = urllib2.urlopen('http://www.voanews.com/learningenglish/home/world/', timeout=10).read()
	return html

def getTitle():
	htmlSource = requestWebHtml()
	htmlSource = htmlSource[htmlSource.find('moreNewsBoxList'): htmlSource.find('right column of Main Content')]
	soup = BeautifulSoup(htmlSource)
	
	tempLink =  soup.findAll('a')
	
	titleList = []
	for temp in tempLink:
		if temp.find('img') == None: # if temp in img will be not existed, this function would return None 
			titleList.append(temp)

	for title in titleList:
		contents, mp3Url = requestContents(title['href'])
		title = str(title.contents)
		title = title[3:len(title)-2]		
#		while title.find('"') != -1 and title.find("'") != -1:
#			title = title.replace("'", "\'")
#			title = title.replace('"', '')
		
		print title

#		print title		
#		print title.contents
		storeDB(title, contents, mp3Url)

#	for title in titleList:
#		print title['href']	print link target
#		print title.contents	print contents = text.


def requestContents(url):
	htmlSource = urllib2.urlopen(url, timeout=10).read()
	htmlSource = htmlSource[htmlSource.find('articleBody')-100: ]
	soup = BeautifulSoup(htmlSource)
	contents = soup.findAll('div', {'class':'articleBody'})
	mp3Url = soup.findAll('li', {'class':'audio'})	
	
	contents = str(contents)
	
	parser = ExtrTextParser()
	parser.feed(contents)
	parser.close()
	contents = parser.getresult()
	
	contents = contents[contents.find('PDF')+4: ]
	while contents.find('\n\n') != -1:
		contents = contents.replace('\n\n', '\n')
	
	mp3Url = str(mp3Url)
	mp3Url = mp3Url[mp3Url.find('http://') : mp3Url.find('">MP3')]

 	return contents, mp3Url

def storeDB(title, content, url):
#	now = time.localtime()
	now = datetime.datetime.now()
#	str_now = now.date()
	print now

	db = MySQLdb.connect(db='testDB', user='root', passwd='thsdydtjr2', host='localhost', charset='utf8', use_unicode=True)
	cusor=db.cursor()
#	nowTime = str(now.tm_year) + '-' + str(now.tm_mon) + '-' + str(now.tm_mday) + ' ' + str(now.tm_hour) + ':' + str(now.tm_min) + ':' + str(now.tm_sec)
#	sql = "insert into testTable(title, contents, mp3url, InputDate) values('" + title + "','" + content + "','" + url +"','" + nowTime +"')"
	cusor.execute('insert into testTable(title, content, mp3url, InputDate)  values("%s", "%s", "%s", "%s")', (title, content, url, now))
	cusor.close()
	db.close()

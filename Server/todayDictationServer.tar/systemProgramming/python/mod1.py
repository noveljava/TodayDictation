#mod1.py
def sum(a, b):
	return a+b
